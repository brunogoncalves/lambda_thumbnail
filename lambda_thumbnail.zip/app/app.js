const app = require('sae-framework');

module.exports = app;